import { Component, OnInit } from '@angular/core';
import { Router} from'@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  mess:string="";
  valid:boolean=false;
  prop:string="";
  demo:any=[
    {'email':'sri@gmail.com','pass':1234567},
    {'email':'rama@gmail.com','pass':1234},
    {'email':'kishan@gmail.com','pass':1234567},
    {'email':'sujan@gmail.com','pass':1234567},
  ]
    constructor(private router: Router) { }
  
    ngOnInit(): void {
    }
    login(value: any,pageName: String){
  
  
     // if(value.emailid == this.demo.emailid && value.password == this.demo.password){
     
      if(value.email == "sri@gmail.com" && value.pass == "1234"){  
     this.mess=`Successfully logged in`;
          this.prop=`#006400`;
          this.valid=true;
          this.router.navigate([`${pageName}`])
          // if(this.valid== true){
          //   return`<a routerLink="/"  >`;
          // }
      }
      else {
     this.mess=`Login not succesful`;
     this.prop=`red`;
     this.valid=false
     
      }
      console.log(value.emailid);
      console.log(value.password);
     // console.log(this.demo.emailid);
    }
    // goTohome(pageName:string):void{
    //   this.router.navigate([`{\pageName}`])
    // }
  
  }