import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carloan',
  templateUrl: './carloan.component.html',
  styleUrls: ['./carloan.component.css']
})
export class CarloanComponent implements OnInit {

  
  carval:number=0;
  homeval:number=0;
  personalval:number=0;
  currency: number=0;

  
  constructor() { }
  
  
  
  ngOnInit(): void {
  }
  
 
  
  
  home(value :any){
  this.homeval= Math.round(value*0.10);
  console.log(this.homeval);
  }
  car(value :any){
  this.carval=Math.round(value*0.07);
  console.log(this.carval);
  }
  personal(value :any){
  this.personalval=Math.round(value*0.05);
  console.log(this.personalval);
  }
}