import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  getData(msg:any){
    throw new Error ('Method not implemented');
  }
// message:string='';
// message1:string='';
message:any[]=[];
constructor() { }



dataServe(msg:any){
// console.log("this message is from Data Service"+msg)
this.message.push(msg);
//this.log.check(msg);//calling log service
}
callData():any{
return this.message;
}
// dS(msg1:any){
// console.log("this message is from Data Service"+msg1)
// this.message1=msg1;
// }
// callD():string{
// return this.message1;
// }



}