import React, { Component } from 'react';
import StripeButton from "./StripeDemo";
class StripeButtonComponent extends Component {
    render() {
        return (
            <div>
                <StripeButton  />
            </div>
        );
    }
}

export default StripeButtonComponent;
