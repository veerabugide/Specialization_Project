import Navigation from "../../components/Navigation";
import Footer from "../../components/Footer";

const AboutUsScreen = () => {
  return (
    <div>
      <Navigation />
      <div className="main1">
        <h3>About Us : </h3>
        <tab>&emsp;</tab> From the last 8 years running an offline store experience,
we have well known the importance of car accessories for any car lover.
In the last 10 years experience we have found the major thing in car accessories is the fitment issue.
It is very difficult to understand when you are going to purchase online.
That's why we always confirm your car model year first before shipping any order.
<br />
        <br />
        <tab>&emsp;</tab>We understand how important is that product for you.
As we are Power Wheels offer you to a wide range of car accessories and car care products.
Including car interior accessories, car exterior accessories,
car lighting products, car care, car styling, car part, car utility, and car electronics product.
<br></br>
        <br />
        <tab>&emsp;</tab>Generally, we use FedEx, Delivery, and Speed-post courier service to deliver the product fast,
deepens on which courier service is best for specific pin-code.
At <b>Power Wheels</b> your money is safe because we have the 15 days return policy as well.
<br></br>
        <br />
        <tab>&emsp;</tab>We provide high-quality car accessories at the best price.
Being the Best Online car accessories shop we provide accessories for all car brands like
Audi , BMW , Datsun , Fiat , Force , Ford , Honda , Hyundai , Jaguar,  Jeep ,
Land Rover, Mahindra , Maruti Suzuki , Mercedes Benz , Mitsubishi , Nissan , Renault , Skoda ,
Tata , Toyota ,Volkswagen, Volvo and more brand.
<br></br>
        <br />

        <tab>&emsp;</tab> <b>Power Wheels</b> is a One-stop On-demand hassle-free solution for all car accessories & car care needs.
<b>Power Wheels</b> would be your personal Garage that would take care of all your car accessories and care needs.
<b>Power Wheels</b> Best online platform will host the best of accessories and provide end-to-end last-mile service to enable convenient, transparent and faster transactions. Carhatke would provide both curated offerings to new car buyers and also provide after-sales services.
So no worries let the <b>Power Wheels</b> take care of your car.
<br></br>
        <br />

        <tab>&emsp;</tab>Car body cover, seat cover, Steering Covers,  black leather seat cover,
music system(subwoofer, speakers, tweeters), chrome grille , 3D no. plate , mats , loud horn ,
Mudflaps , Windshield Wipers , Car 3D Mats , Car Chargers , Car Emergency Kits , Car Polisher ,
 Car Vacuum Cleaner ,  Jumper Cable , Towing Cable , Tyre Inflator , Car Body Covers , Car Beading ,
 Car Handle Door Latch Covers , Car Mirror Cover , Car Window Trim- Garnish ,  Car Wrap Sheets ,
 Car-Front-Grills ,  Roof Rails , Window Door Visor , Car GPS Device and Mobile Holder , Car Boot Mat ,
 Car Center Console Armrest , Boot-Trunk Mats , Car 3D Mats ,  Car 5D Mats ,  Car 7D Mats ,
 Car All Weather Tech Mats , Car Rubber Mats , Car Automatic Sunshade , Custom Fit Car Curtain , Gear Knobs ,
  Car Foot Step Sill Plate , Car DRL Lighting , Car Fog Lights , Car Headlights ,
  Car Hid and LED Lights Bulbs, Car Interior Lighting, Car Off-Road Lights , Car Tail Lights , Car Camera ,
  Car Rear View Monitor , Air compressors and many more, gives us the upper hand to provide
  the best fitment and high-quality products.
<br></br>
        <br />
        <tab>&emsp;</tab>No matter whether you're doing basic repairs and maintenance,
modifying your car's street appeal and performance, or adding high-tech lighting and electronics,
our great selection of brand name products and knowledgeable associates will ensure success with all your
 accessories
      </div>
      <Footer />
    </div>
  );
};
export default AboutUsScreen;
