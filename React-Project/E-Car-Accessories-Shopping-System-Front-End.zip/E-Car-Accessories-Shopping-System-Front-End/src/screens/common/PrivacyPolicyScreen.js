import Navigation from "../../components/Navigation";
import Footer from "../../components/Footer"; 

const PrivacyPolicyScreen = () => {
    return (
        <div>
             <Navigation/>
            <div className="main1">
            <h3>Privacy Policy : </h3>
            <h5>Personal Information</h5>
            <p>
            <tab>&emsp;</tab>We value the trust you place in us. That's why we insist upon the highest standards for secure Personal information and customer information privacy. Please read the following statement to learn about our information gathering and dissemination practices.
            </p>
            <h5>What information is, or may be, collected form you?</h5>
            <p>
            Something here</p> 
        </div>
        <Footer/>
        </div>
      
    );
}
export default PrivacyPolicyScreen




