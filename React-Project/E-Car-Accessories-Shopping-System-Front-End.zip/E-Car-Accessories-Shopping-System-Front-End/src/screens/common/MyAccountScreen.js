import "../../App.css"
import Navigation from "../../components/Navigation";
import Footer from "../../components/Footer";

const MyAccountScreen = (props) => {
    return (
        <div>
             <Navigation/>
            <div className="container">
            <h5>From MyAccount Screen</h5>
            <br/>
            <br/> 
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
        </div>
        <Footer/>
        </div>
    )
}
export default MyAccountScreen