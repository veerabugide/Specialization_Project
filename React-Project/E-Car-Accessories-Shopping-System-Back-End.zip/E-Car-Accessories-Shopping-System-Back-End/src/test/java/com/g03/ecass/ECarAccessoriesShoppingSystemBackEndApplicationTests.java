package com.g03.ecass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECarAccessoriesShoppingSystemBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
