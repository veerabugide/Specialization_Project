package com.g03.ecass.pojos.entity;

public enum OrderStatus {
	PENDING, DELIVERED, CANCELD
}
