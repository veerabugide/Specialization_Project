package com.g03.ecass.pojos.entity;

public enum Status {
	PENDING, PAID

}
