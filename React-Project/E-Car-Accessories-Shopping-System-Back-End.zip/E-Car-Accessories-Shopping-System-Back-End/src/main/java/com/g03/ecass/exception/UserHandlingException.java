package com.g03.ecass.exception;

@SuppressWarnings("serial")
public class UserHandlingException extends Exception
{
	public UserHandlingException(String message)
	{
		super(message);
	}

}
