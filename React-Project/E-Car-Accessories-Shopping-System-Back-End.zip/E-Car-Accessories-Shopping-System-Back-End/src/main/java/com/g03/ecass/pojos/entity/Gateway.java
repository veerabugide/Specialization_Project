package com.g03.ecass.pojos.entity;

public enum Gateway {
	CARD, DEBIT, CASH_ON_DELIVERY,CREDIT
}
