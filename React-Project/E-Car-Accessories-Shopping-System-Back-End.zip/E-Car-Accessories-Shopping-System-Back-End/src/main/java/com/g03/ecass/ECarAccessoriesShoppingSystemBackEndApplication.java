package com.g03.ecass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ECarAccessoriesShoppingSystemBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ECarAccessoriesShoppingSystemBackEndApplication.class, args);
	}

}
